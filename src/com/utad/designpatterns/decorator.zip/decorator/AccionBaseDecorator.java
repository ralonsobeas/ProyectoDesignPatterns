package com.utad.designpatterns.decorator;

public interface AccionBaseDecorator extends AccionDecorator{
	public AccionDecorator getAccionDecorator();
}
